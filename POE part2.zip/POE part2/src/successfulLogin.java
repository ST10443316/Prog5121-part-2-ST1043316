import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.Locale;

class Task {
    private static int taskCount = 0;//keep trac of the number of tasks

    private int taskNumber;
    private String taskName;
    private String taskDescription;
    private String developerDetails;
    private int taskDuration;
    private String taskID;
    private String taskStatus;

    public Task(String taskName, String taskDescription, String developerDetails, int taskDuration, String taskStatus){
        this.taskNumber = ++taskCount;
        this.taskName = taskName;
        this.taskDescription=taskDescription;
        this.developerDetails=developerDetails;
        this.taskDuration=taskDuration;
        this.taskStatus=taskStatus;
        this.taskID = generateTaskID();
    }
    private String generateTaskID(){
        String taskNamePart = taskName.substring(0, Math.min(2, taskName.length())).toLowerCase();
        String developerPart = developerDetails.substring(Math.max(0, developerDetails.length() - 3)).toUpperCase();
        return taskNamePart + ":" + taskNumber + ":" + developerPart;
    }
}

public class successfulLogin {
    public static void main(String[] args) {
        //Display the messagse
        System.out.println("Welcome to EasyKanban");
         
        String menu = "choose an option:\n" +
                "1. Add task 1\n" +
                "2. Show report 2\n " +
                "3. Quit 3";
        String input = JOptionPane.showInputDialog(null, menu, "Numeric menu", JOptionPane.INFORMATION_MESSAGE);

        if (input != null){
            try {
                int choice = Integer.parseInt(input);
                switch (choice) {
                    case 1:
                        JOptionPane.showMessageDialog(null, "option 1");//soon to change
                        break;
                    case 2:
                        JOptionPane.showMessageDialog(null, "Coming soon");
                        break;
                    case 3:
                        JOptionPane.showMessageDialog(null,"optio 3");
                        boolean exit = true;
                        break;
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "incorect try again");
            }
        } else {
            JOptionPane.showMessageDialog(null, "no input recieved"); //change this
        }
        //adapted from TheServerSide,Simple showOptionDialog defaults,11 september 2022,Cameron McKenzie,URL:https://www.theserverside.com/blog/Coffee-Talk-Java-News-Stories-and-Opinions/Javas-JOptionPane-showOptionDialog-by-Example
        //adapted from DANIWEB,Software development Forum,Posted 13years ago by user:inni2626, url:https://www.daniweb.com/programming/software-development/threads/353520/menu-option
    }
}

private static void addTasks(ArrayList<String> tasks) {
    String taskCountInput = JOptionPane.showInputDialog(null, "how many tasks are you adding", "Add Task", JOptionPane.INFORMATION_MESSAGE);

    if (taskCountInput != null) {
        try {
            int taskCount = Integer.parseInt(taskCountInput);

            for (int i = 0; i < taskCount; i++) {
                String task = JOptionPane.showInputDialog(null, "Enter task" + (i + 1) + ":", "Add Task", JOptionPane.INFORMATION_MESSAGE);

                String taskDescription;
                while (true) {
                    taskDescription = JOptionPane.showInputDialog(null, "Enter task description" + (i + 1) + ":", "Add Task", JOptionPane.INFORMATION_MESSAGE);
                    if (taskDescription != null && taskDescription.length() <= 50) {
                        JOptionPane.showMessageDialog(null, "Task successfully captured.");
                        break;
                    } else {
                        JOptionPane.showMessageDialog(null, "please enter a task description of less than 50 characters.");
                    }
                }
                String developerDetails = JOptionPane.showInputDialog(null, "Enter developer details" + (i + 1) + ":", "Add Task", JOptionPane.INFORMATION_MESSAGE);
                String taskDurationInput = JOptionPane.showInputDialog(null, "Enter task duration in hours" + (i + 1) + ":", "Add task", JOptionPane.INFORMATION_MESSAGE);

                String[] statusOptions = {"To Do", "Done", "Doing"};
                int statusselection =JOptionPane.showInputDialog(null, "select task status" + (i + 1) ":","Add Task", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, statusOptions, statusOptions[0]);
                String taskStatus = statusOptions[statusselection];

                try {
                    int taskDuration = Integer.parseInt(taskDurationInput);

                    if (task != null && !task.trim().isEmpty() &&
                            taskDescription != null && !taskDescription.trim().isEmpty() &&
                            developerDetails != null && !developerDetails.trim().isEmpty() &&
                            taskStatus != null && !taskStatus.trim().isEmpty()) {
                        tasks.add(new Task(task, taskDescription, developerDetails, taskDuration, taskStatus));
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid task.field is neede.");//come back to this
                        i--;//so that it repeats
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Invalid duration. Enter a valid number");
                    i--;
                }
            } catch(NumberFormatException e){
                JOptionPane.showMessageDialog(null, "Invalid number of tasks.enter a valid amount");
            }
        } else{
            JOptionPane.showMessageDialog(null, "field is empty.returning to main menu");
        }
    }
}//the section above needs some changes


public void main() {
}
