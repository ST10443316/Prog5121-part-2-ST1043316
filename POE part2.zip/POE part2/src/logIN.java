public class logIN {
    public static String checkUserName(String username){
        if (username.length()<=5 && username.contains("_")){
            return "true";

        }
        if(username.length()>5 && !username.contains("_")){
            return "false";
        }
        return username;
    }

    public static String checkPasswordComplexity(String password) {
        if(password.length()<8 && password.contains("[!@#$%^&*]") && password.contains("[0-9]")){
            return "true";
        }
        if(password.length()<8 && !password.contains("[!@#$%^&*]") && !password.contains("[0-9]")){
            return "false";
        }
        return password;
    }
    public static String registerUser(String username , String password){

        if(password.length()>8 && password.matches("[A-Z]") && password.matches("[!@#$%^&*]") && password.matches("[0-9]")){
            return "true";

        }
        else if(password.length()<8 && !password.matches("[A-Z]") && !password.matches("[!@#$%^&*]") && !password.matches("[0-9]"));
        return username;
    }

    String returnLoginStatus=("successfull");

    public String getReturnLoginStatus() {
        return returnLoginStatus;
    }

}
