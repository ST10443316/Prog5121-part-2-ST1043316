import java.util.Scanner;

public class AccountInfo{


    public static void main(String[] args){

        System.out.println("Enter Log in details");

        System.out.print("Enter Username");
        Scanner scanner = new Scanner(System.in);
        String username = scanner.nextLine();

        System.out.print("Enter password");
        String password = scanner.nextLine();

        System.out.print("Enter firstName");
        String firstName  = scanner.nextLine();

        System.out.print("Enter surname");
        String surname = scanner.nextLine();

        String validationMessage = validateInputs(username, password, firstName, surname);
        System.out.println(validationMessage);
        scanner.close();


        //question 2
        String inputUsername = ("Enter username");
        String inputPassword = ("Enter password");
        if(inputUsername.equals(username) && inputPassword.equals(password)){
            System.out.println("Welcome"+firstName+" "+surname+",it is great to see you again");
        }
        else if(!inputUsername.equals(username) && !inputPassword.equals(password)){
            System.out.println("Username or password incorrect,please try again");
        }
    }

    private static String validateInputs(String username, String password, String surname, String firstName) {

        if (username.isEmpty()|| password.isEmpty()|| firstName.isEmpty()|| surname.isEmpty()){
            return "Field is required.enter the correct information.";
        }
        if (username.length() <= 5 && username.contains("_")){
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.";
        }
        else if (username.length() > 5){
            return "Username successfully captured";
        }
        //figure out the password conditions

        if (password.length()>8 && !password.matches("[A-Z]") && !password.matches("[!@#$%^&*]") && !password.matches("[0-9]")){
            return "incorect";
        }
        return "Account information captured successfully";


        }


    }






